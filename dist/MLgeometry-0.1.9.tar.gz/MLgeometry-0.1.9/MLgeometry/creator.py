"""
Create Objects from dictionaries (Deprecated)

JCA
Vaico
"""
from MLgeometry.Object import Object


# Backward compatibility: Support with old versions
from_dict = Object.from_dict
create_geometry = Object.create_geometry
